package com.example.irrigation;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.os.Handler;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Switch;
import android.widget.Toast;

import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
public class MainActivity extends AppCompatActivity {


    FirebaseDatabase rootnode;
    DatabaseReference reference;
    EditText nmb_1,nmb_2;
    Switch on_off;
    int last;
    int last_2;
    String on_switch = "ON", off_switch = "OFF";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
         //
         nmb_1 = (EditText) findViewById(R.id.editText);
         nmb_2 = (EditText) findViewById(R.id.editText2);
         on_off = (Switch) findViewById(R.id.switch1);
         Button _init = (Button) findViewById(R.id.button);

             _init.setOnClickListener(new View.OnClickListener() {
                 @Override
                 public void onClick(View v) {
                     if(!nmb_1.getText().toString().equals("") || !nmb_2.getText().toString().equals("")) {
                         last = Integer.parseInt(nmb_1.getText().toString());
                         last_2 = Integer.parseInt(nmb_2.getText().toString());
                         rootnode = FirebaseDatabase.getInstance();
                         reference = rootnode.getReference("power");
                         reference.setValue(+last);
                         reference = rootnode.getReference("time");
                         reference.setValue(+last_2);
                         reference = rootnode.getReference("activity");
                         if(on_off.isChecked())
                         {
                             reference.setValue(on_switch);
                             new Handler().postDelayed(new Runnable() {
                                 @Override
                                 public void run() {
                                 reference.setValue(off_switch);
                                 }
                             }, last*660);
                         }
                         else
                         {
                             reference.setValue(off_switch);
                         }
                         Toast.makeText(MainActivity.this, "Irrigation event is started!", Toast.LENGTH_SHORT).show();
                         }
                         else
                         {
                         Toast.makeText(MainActivity.this, "Your text is empty!", Toast.LENGTH_SHORT).show();
                         }
                 }
             });



    }
}
